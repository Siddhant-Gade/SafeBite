import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import logging
import math
from datetime import timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def train_test_split_data(df, target_col='Close', test_size=0.2, look_back=30):
    """
    Split the data into training and testing sets.
    
    Args:
        df (pd.DataFrame): Processed dataframe with technical indicators
        target_col (str): Target column to predict
        test_size (float): Proportion of data to use for testing
        look_back (int): Number of previous days to use for each prediction
    
    Returns:
        tuple: X_train, X_test, y_train, y_test, scaler, feature_names
    """
    try:
        # Make sure target column exists
        if target_col not in df.columns:
            logger.warning(f"Target column '{target_col}' not found in dataframe. Available columns: {df.columns.tolist()}")
            # If target column not found, let's try to find the most suitable alternative
            if len(df.columns) > 0:
                target_col = df.columns[0]  # Use the first column as target
                logger.info(f"Using '{target_col}' as target column instead")
            else:
                raise KeyError(f"No columns available in dataframe")
        
        # Select features (exclude Open, High, Low as they're not available for future prediction)
        exclude_cols = ['Open', 'High', 'Low']
        feature_cols = [col for col in df.columns if col != target_col and col not in exclude_cols]
        
        # Create a dataframe with features and target
        data = df[feature_cols + [target_col]].copy()
        
        # Scale the data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(data)
        
        # Create X and y
        X = scaled_data[:, :-1]  # All columns except the last one (target)
        y = scaled_data[:, -1:]  # Last column is the target
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, shuffle=False)
        
        logger.info(f"Data split completed. X_train shape: {X_train.shape}, X_test shape: {X_test.shape}")
        
        return X_train, X_test, y_train, y_test, scaler, feature_cols
    
    except Exception as e:
        logger.error(f"Error in train_test_split_data: {str(e)}")
        raise

def train_ml_models(X_train, y_train, X_test, y_test, selected_models):
    """
    Train machine learning models on the training data.
    
    Args:
        X_train (np.array): Training features
        y_train (np.array): Training target
        X_test (np.array): Test features
        y_test (np.array): Test target
        selected_models (list): List of model names to train
    
    Returns:
        tuple: Dictionary of trained models and dictionary of performance metrics
    """
    try:
        models = {}
        performance_metrics = {}
        
        # Define model constructors
        model_constructors = {
            "Linear Regression": LinearRegression(),
            "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42),
            "Support Vector Machine": SVR(kernel='rbf')
        }
        
        # Train selected models
        for model_name in selected_models:
            if model_name in model_constructors:
                logger.info(f"Training {model_name} model...")
                
                # Initialize model
                model = model_constructors[model_name]
                
                # Train model
                model.fit(X_train, y_train.ravel())
                
                # Save model
                models[model_name] = model
                
                # Make predictions on test set
                y_pred = model.predict(X_test)
                
                # Calculate metrics
                mae = mean_absolute_error(y_test, y_pred)
                mse = mean_squared_error(y_test, y_pred)
                rmse = math.sqrt(mse)
                r2 = r2_score(y_test, y_pred)
                
                # Save metrics
                performance_metrics[model_name] = {
                    "mae": mae,
                    "mse": mse,
                    "rmse": rmse,
                    "r2": r2,
                    "test_predictions": y_pred
                }
                
                logger.info(f"{model_name} trained. MAE: {mae:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}")
        
        return models, performance_metrics
    
    except Exception as e:
        logger.error(f"Error training models: {str(e)}")
        return {}, {}

def make_ml_predictions(model, df, scaler, feature_names, days_to_predict=7):
    """
    Make future predictions using ML models.
    
    Args:
        model: Trained machine learning model
        df (pd.DataFrame): Historical data with features
        scaler: Fitted scaler to transform data
        feature_names (list): List of feature column names
        days_to_predict (int): Number of days to predict ahead
    
    Returns:
        np.array: Array of predicted prices
    """
    try:
        predictions = []
        
        # Create a copy of the latest data
        latest_data = df.copy().iloc[-1:]
        
        # Determine the target column (use first column if 'Close' not available)
        target_col = 'Close'
        if target_col not in df.columns and len(df.columns) > 0:
            target_col = df.columns[0]
            logger.info(f"Using '{target_col}' as target column for predictions")
        
        # Make predictions for each future day
        for i in range(days_to_predict):
            # Get the latest features
            latest_features = latest_data[feature_names].values
            
            # Scale the features
            scaled_features = scaler.transform(latest_data[feature_names + [target_col]])[:, :-1]
            
            # Make prediction
            scaled_prediction = model.predict(scaled_features)
            
            # Inverse transform to get actual price
            # Create a dummy array with the predicted value in the last column
            dummy = np.zeros((1, len(feature_names) + 1))
            dummy[0, -1] = scaled_prediction[0]
            prediction = scaler.inverse_transform(dummy)[0, -1]
            
            # Append prediction
            predictions.append(prediction)
            
            # Update the latest data for next prediction
            # This is a simplified approach - in reality, you would also need to update technical indicators
            next_day = latest_data.index[0] + timedelta(days=1)
            latest_data = latest_data.copy()
            latest_data.index = [next_day]
            latest_data[target_col] = prediction
            
            # Simple update of other features (this is a simplification)
            # In a more sophisticated model, you would recalculate all technical indicators
            for feature in feature_names:
                if feature in ['MA7', 'MA14', 'MA30', 'BB_middle']:
                    latest_data[feature] = prediction
        
        return np.array(predictions)
    
    except Exception as e:
        logger.error(f"Error making ML predictions: {str(e)}")
        return np.array([df['Close'].iloc[-1]] * days_to_predict)  # Fallback to last known price
