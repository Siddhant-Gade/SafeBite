import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import logging
import math
from datetime import timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LSTMModel(nn.Module):
    """
    LSTM model for time series prediction
    """
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
        super(LSTMModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        
        # LSTM layer
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        
        # Fully connected layer
        self.fc = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x):
        # Initialize hidden state with zeros
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        
        # Forward propagate LSTM
        out, _ = self.lstm(x, (h0, c0))
        
        # Get the output from the last time step
        out = self.fc(out[:, -1, :])
        return out

def create_sequences(data, seq_length):
    """
    Create sequences for LSTM training
    
    Args:
        data (np.array): Input data
        seq_length (int): Sequence length (lookback period)
    
    Returns:
        tuple: X sequences and y target values
    """
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i+seq_length])
        y.append(data[i+seq_length, 0])  # Target is the Close price
    return np.array(X), np.array(y)

def train_lstm_model(df, test_size=0.2, seq_length=30, epochs=50, batch_size=32):
    """
    Train LSTM model on Bitcoin price data
    
    Args:
        df (pd.DataFrame): DataFrame with Bitcoin price and features
        test_size (float): Proportion of data to use for testing
        seq_length (int): Sequence length for LSTM (lookback period)
        epochs (int): Number of training epochs
        batch_size (int): Batch size for training
    
    Returns:
        tuple: Trained LSTM model, scaler, and performance metrics
    """
    try:
        # Determine the target column (use first column if 'Close' not available)
        target_col = 'Close'
        if target_col not in df.columns and len(df.columns) > 0:
            target_col = df.columns[0]
            logger.info(f"Using '{target_col}' as target column for LSTM model")
        
        # Prepare data for LSTM
        # We'll use Close price (or alternative) as the target and relevant features as inputs
        features = [target_col, 'Volume', 'MA7', 'MA14', 'MA30', 'RSI', 'MACD', 'BB_position']
        
        # Make sure all required features exist
        available_features = [f for f in features if f in df.columns]
        if not available_features:
            logger.error("No features available for LSTM model")
            return None, None, {"mae": 999, "mse": 999, "rmse": 999, "r2": 0, "test_predictions": []}
            
        data = df[available_features].values
        
        # Scale the data
        scaler = MinMaxScaler(feature_range=(0, 1))
        data_scaled = scaler.fit_transform(data)
        
        # Create sequences
        X, y = create_sequences(data_scaled, seq_length)
        
        # Split into train and test sets
        train_size = int(len(X) * (1 - test_size))
        X_train, X_test = X[:train_size], X[train_size:]
        y_train, y_test = y[:train_size], y[train_size:]
        
        # Convert to PyTorch tensors
        X_train_tensor = torch.FloatTensor(X_train)
        y_train_tensor = torch.FloatTensor(y_train).view(-1, 1)
        X_test_tensor = torch.FloatTensor(X_test)
        y_test_tensor = torch.FloatTensor(y_test).view(-1, 1)
        
        # Create dataset and dataloader
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        # Model parameters
        input_dim = X_train.shape[2]  # Number of features
        hidden_dim = 64
        num_layers = 2
        output_dim = 1
        
        # Initialize model
        model = LSTMModel(input_dim, hidden_dim, num_layers, output_dim)
        
        # Loss function and optimizer
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)
        
        # Train the model
        model.train()
        for epoch in range(epochs):
            running_loss = 0.0
            for inputs, targets in train_loader:
                # Forward pass
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                
                # Backward and optimize
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
                running_loss += loss.item()
            
            # Print progress every 10 epochs
            if (epoch + 1) % 10 == 0:
                logger.info(f'Epoch [{epoch+1}/{epochs}], Loss: {running_loss/len(train_loader):.4f}')
        
        # Evaluate the model
        model.eval()
        with torch.no_grad():
            test_predictions = model(X_test_tensor)
            test_loss = criterion(test_predictions, y_test_tensor)
            
            # Convert predictions to numpy
            test_predictions = test_predictions.numpy()
            
            # Create dummy arrays for inverse scaling
            dummy_test_pred = np.zeros((len(test_predictions), len(available_features)))
            dummy_test_pred[:, 0] = test_predictions.flatten()  # Place predictions in the first column (Close)
            
            dummy_test_actual = np.zeros((len(y_test), len(available_features)))
            dummy_test_actual[:, 0] = y_test  # Place actual values in the first column
            
            # Inverse transform to get actual prices
            predicted_prices = scaler.inverse_transform(dummy_test_pred)[:, 0]
            actual_prices = scaler.inverse_transform(dummy_test_actual)[:, 0]
            
            # Calculate metrics
            mae = mean_absolute_error(actual_prices, predicted_prices)
            mse = mean_squared_error(actual_prices, predicted_prices)
            rmse = math.sqrt(mse)
            r2 = r2_score(actual_prices, predicted_prices)
            
            logger.info(f'LSTM Model - Test MAE: {mae:.4f}, RMSE: {rmse:.4f}, R²: {r2:.4f}')
            
            # Save metrics
            metrics = {
                "mae": mae,
                "mse": mse,
                "rmse": rmse,
                "r2": r2,
                "test_predictions": predicted_prices
            }
        
        logger.info("LSTM model training completed")
        return model, scaler, metrics
    
    except Exception as e:
        logger.error(f"Error training LSTM model: {str(e)}")
        # Return a dummy model and metrics
        return None, None, {"mae": 999, "mse": 999, "rmse": 999, "r2": 0, "test_predictions": []}

def make_lstm_predictions(model, df, scaler, days_to_predict=7, seq_length=30):
    """
    Make future predictions using the trained LSTM model
    
    Args:
        model: Trained LSTM model
        df (pd.DataFrame): Historical data with features
        scaler: Fitted scaler to transform data
        days_to_predict (int): Number of days to predict ahead
        seq_length (int): Sequence length used for training
    
    Returns:
        np.array: Array of predicted prices
    """
    try:
        # Determine the target column (use first column if 'Close' not available)
        target_col = 'Close'
        if target_col not in df.columns and len(df.columns) > 0:
            target_col = df.columns[0]
            logger.info(f"Using '{target_col}' as target column for LSTM predictions")
            
        # For fallback case
        if model is None:
            logger.warning("No LSTM model provided for prediction")
            if target_col in df.columns:
                return np.array([df[target_col].iloc[-1]] * days_to_predict)
            else:
                return np.array([0] * days_to_predict)
        
        # Prepare features
        features = [target_col, 'Volume', 'MA7', 'MA14', 'MA30', 'RSI', 'MACD', 'BB_position']
        available_features = [f for f in features if f in df.columns]
        
        # Get the last sequence from the data
        last_sequence = df[available_features].values[-seq_length:]
        
        # Scale the sequence
        last_sequence_scaled = scaler.transform(last_sequence)
        
        # Convert to tensor
        last_sequence_tensor = torch.FloatTensor(last_sequence_scaled).unsqueeze(0)  # Add batch dimension
        
        # Make predictions
        model.eval()
        predictions = []
        
        # Current sequence to start with
        current_sequence = last_sequence_scaled
        
        with torch.no_grad():
            for _ in range(days_to_predict):
                # Convert current sequence to tensor
                sequence_tensor = torch.FloatTensor(current_sequence).unsqueeze(0)
                
                # Get prediction
                pred = model(sequence_tensor)
                
                # Convert prediction to numpy
                pred_numpy = pred.item()
                
                # Create a dummy array for inverse scaling
                dummy_pred = np.zeros((1, len(available_features)))
                dummy_pred[0, 0] = pred_numpy  # Place prediction in the first column (Close)
                
                # Inverse transform to get actual price
                predicted_price = scaler.inverse_transform(dummy_pred)[0, 0]
                predictions.append(predicted_price)
                
                # Update sequence for next prediction
                # Remove the first element and append the new prediction
                new_row = current_sequence[-1].copy()
                new_row[0] = pred_numpy  # Update Close price with prediction
                current_sequence = np.vstack([current_sequence[1:], new_row])
        
        return np.array(predictions)
    
    except Exception as e:
        logger.error(f"Error making LSTM predictions: {str(e)}")
        # Determine the target column for fallback
        target_col = 'Close'
        if target_col in df.columns:
            return np.array([df[target_col].iloc[-1]] * days_to_predict)  # Fallback to last known price
        elif len(df.columns) > 0:
            # Use first column as fallback
            target_col = df.columns[0] 
            return np.array([df[target_col].iloc[-1]] * days_to_predict)
        else:
            return np.array([0] * days_to_predict)
