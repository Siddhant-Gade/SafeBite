import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def plot_bitcoin_history(df, show_volume=False):
    """
    Plot the historical Bitcoin price data
    
    Args:
        df (pd.DataFrame): DataFrame with Bitcoin OHLCV data
        show_volume (bool): Whether to include volume in the plot
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if show_volume:
        # Create figure with secondary y-axis for volume
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        
        # Add price trace
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['Close'],
                mode='lines',
                name='BTC Price',
                line=dict(color='blue', width=2)
            ),
            secondary_y=False,
        )
        
        # Add volume trace
        fig.add_trace(
            go.Bar(
                x=df.index,
                y=df['Volume'],
                name='Volume',
                marker=dict(color='rgba(0, 128, 0, 0.3)')
            ),
            secondary_y=True,
        )
        
        # Add titles and labels
        fig.update_layout(
            title='Bitcoin Price and Volume History',
            xaxis_title='Date',
            yaxis_title='Price (USD)',
            legend=dict(x=0, y=1),
            hovermode="x unified"
        )
        
        # Set y-axes titles
        fig.update_yaxes(title_text="Price (USD)", secondary_y=False)
        fig.update_yaxes(title_text="Volume", secondary_y=True)
    else:
        # Create simple line chart
        fig = go.Figure()
        
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['Close'],
                mode='lines',
                name='BTC Price',
                line=dict(color='blue', width=2)
            )
        )
        
        # Add titles and labels
        fig.update_layout(
            title='Bitcoin Price History',
            xaxis_title='Date',
            yaxis_title='Price (USD)',
            hovermode="x unified"
        )
    
    # Add range slider
    fig.update_layout(
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=3, label="3m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            ),
            rangeslider=dict(visible=True),
            type="date"
        )
    )
    
    return fig

def plot_predictions(historical_df, future_dates, predictions):
    """
    Plot the historical data along with predictions
    
    Args:
        historical_df (pd.DataFrame): DataFrame with historical Bitcoin data
        future_dates (list): List of dates for future predictions
        predictions (dict): Dictionary of model names and predictions
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    fig = go.Figure()
    
    # Add historical data
    fig.add_trace(
        go.Scatter(
            x=historical_df.index,
            y=historical_df['Close'],
            mode='lines',
            name='Historical Price',
            line=dict(color='black', width=2)
        )
    )
    
    # Add predictions for each model
    colors = ['blue', 'green', 'red', 'purple', 'orange']
    for i, (model_name, preds) in enumerate(predictions.items()):
        fig.add_trace(
            go.Scatter(
                x=future_dates,
                y=preds,
                mode='lines+markers',
                name=f'{model_name} Prediction',
                line=dict(color=colors[i % len(colors)], width=2, dash='dash'),
                marker=dict(size=8)
            )
        )
    
    # Add titles and labels
    fig.update_layout(
        title='Bitcoin Price Forecast',
        xaxis_title='Date',
        yaxis_title='Price (USD)',
        legend=dict(x=0, y=1),
        hovermode="x unified"
    )
    
    return fig

def plot_model_performance(metrics):
    """
    Plot the performance metrics for different models
    
    Args:
        metrics (dict): Dictionary of model names and performance metrics
    
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    # Create figure with subplots for different metrics
    fig = make_subplots(rows=1, cols=3, subplot_titles=('Mean Absolute Error', 'Root Mean Squared Error', 'R² Score'))
    
    # Extract model names and metrics
    models = list(metrics.keys())
    mae_values = [metrics[model]['mae'] for model in models]
    rmse_values = [metrics[model]['rmse'] for model in models]
    r2_values = [metrics[model]['r2'] for model in models]
    
    # Create display names (LSTM -> LSTM Neural Network)
    display_names = ["LSTM Neural Network" if model == "LSTM" else model for model in models]
    
    # Add MAE bars
    fig.add_trace(
        go.Bar(
            x=display_names,
            y=mae_values,
            name='MAE',
            marker_color='indianred'
        ),
        row=1, col=1
    )
    
    # Add RMSE bars
    fig.add_trace(
        go.Bar(
            x=display_names,
            y=rmse_values,
            name='RMSE',
            marker_color='lightsalmon'
        ),
        row=1, col=2
    )
    
    # Add R² bars
    fig.add_trace(
        go.Bar(
            x=display_names,
            y=r2_values,
            name='R²',
            marker_color='royalblue'
        ),
        row=1, col=3
    )
    
    # Update layout
    fig.update_layout(
        title='Model Performance Comparison',
        height=400,
        showlegend=False
    )
    
    return fig

def create_metric_card(title, value, delta=None):
    """
    Create a metric card with styled formatting
    
    Args:
        title (str): Title of the metric
        value (str): Value to display
        delta (str, optional): Delta value to display
    """
    if delta:
        st.metric(
            label=title,
            value=value,
            delta=delta
        )
    else:
        st.metric(
            label=title,
            value=value
        )
