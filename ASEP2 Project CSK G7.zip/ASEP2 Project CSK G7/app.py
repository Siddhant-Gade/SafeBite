import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import time
from datetime import datetime, timedelta
import logging
import traceback

from data_utils import fetch_bitcoin_data, process_data
from model_utils import train_test_split_data, train_ml_models, make_ml_predictions
from lstm_model import train_lstm_model, make_lstm_predictions
from visualization_utils import (
    plot_bitcoin_history, 
    plot_predictions, 
    plot_model_performance,
    create_metric_card
)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set page config
st.set_page_config(
    page_title="Bitcoin Price Prediction",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# App title and description
st.title("Bitcoin Price Prediction App")
st.markdown("""
This application analyzes historical Bitcoin data and predicts future prices using machine learning and deep learning models.
""")

# Sidebar
st.sidebar.title("Options")

# Date range selector for historical data
st.sidebar.subheader("Historical Data Period")
days_history = st.sidebar.slider("Days of historical data", 
                      min_value=30, 
                      max_value=1825,  # 5 years
                      value=365,  # 1 year default
                      step=30)

# Prediction period selector
st.sidebar.subheader("Prediction Settings")
prediction_days = st.sidebar.slider("Days to predict ahead", 
                        min_value=1, 
                        max_value=30, 
                        value=7,
                        step=1)

# Model selection
st.sidebar.subheader("Model Selection")
selected_models = st.sidebar.multiselect(
    "Select prediction models",
    ["Linear Regression", "Random Forest", "Support Vector Machine", "LSTM Neural Network"],
    default=["Linear Regression", "LSTM Neural Network"]
)

# Feature selection
st.sidebar.subheader("Feature Selection")
feature_options = ["Price", "Volume", "Technical Indicators", "Market Sentiment"]
selected_features = st.sidebar.multiselect(
    "Select features to include",
    feature_options,
    default=["Price", "Volume", "Technical Indicators"]
)

# About section
st.sidebar.markdown("---")
st.sidebar.subheader("About")
st.sidebar.info(
    "This app uses historical Bitcoin data to predict future prices using "
    "machine learning and deep learning models. The predictions are for educational "
    "purposes only and should not be considered financial advice."
)

# Create tabs
tab1, tab2, tab3, tab4 = st.tabs(["Real-time Data", "Historical Analysis", "Predictions", "Model Performance"])

try:
    # Data loading
    with st.spinner("Fetching Bitcoin data..."):
        # Get the data
        df = fetch_bitcoin_data(days=days_history)
        
        if df is not None and not df.empty:
            # Process the data
            processed_df = process_data(df)
            
            # Get latest price for display
            latest_price = df['Close'].iloc[-1]
            previous_price = df['Close'].iloc[-2]
            price_change = (latest_price - previous_price) / previous_price * 100
            
            # Split data for model training
            X_train, X_test, y_train, y_test, scaler, feature_names = train_test_split_data(processed_df)
            
            # Train models
            models = {}
            performance_metrics = {}
            
            with st.spinner("Training models..."):
                if any(model in ["Linear Regression", "Random Forest", "Support Vector Machine"] for model in selected_models):
                    ml_models, ml_metrics = train_ml_models(X_train, y_train, X_test, y_test, selected_models)
                    models.update(ml_models)
                    performance_metrics.update(ml_metrics)
                
                if "LSTM Neural Network" in selected_models:
                    lstm_model, lstm_scaler, lstm_metrics = train_lstm_model(processed_df, test_size=0.2)
                    models["LSTM"] = lstm_model
                    performance_metrics["LSTM"] = lstm_metrics
            
            # Tab 1: Real-time Data
            with tab1:
                st.subheader("Current Bitcoin Price")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    # Current price metric
                    create_metric_card(
                        title="Current Price",
                        value=f"${latest_price:.2f}",
                        delta=f"{price_change:.2f}% in 24h"
                    )
                
                with col2:
                    # Market cap
                    volume = df['Volume'].iloc[-1]
                    create_metric_card(
                        title="24h Trading Volume",
                        value=f"${volume:,.0f}"
                    )
                
                with col3:
                    # 7-day change
                    week_change = ((df['Close'].iloc[-1] - df['Close'].iloc[-8]) / df['Close'].iloc[-8] * 100) if len(df) >= 8 else 0
                    create_metric_card(
                        title="7-Day Change",
                        value=f"{week_change:.2f}%"
                    )
                
                # Display recent price chart
                st.subheader("Recent Price Movement")
                recent_df = df.tail(30)  # Last 30 days
                fig = plot_bitcoin_history(recent_df)
                st.plotly_chart(fig, use_container_width=True)
                
                # Display latest data rows
                st.subheader("Latest Data")
                st.dataframe(df.tail(5))
                
             
            # Tab 2: Historical Analysis
            with tab2:
                st.subheader(f"Bitcoin Price History (Last {days_history} Days)")
                
                # Full historical chart
                fig = plot_bitcoin_history(df, show_volume=True)
                st.plotly_chart(fig, use_container_width=True)
                
                # Technical indicators
                st.subheader("Technical Indicators")
                
                # Display the processed dataframe with indicators
                indicator_cols = [col for col in processed_df.columns if col not in df.columns]
                if indicator_cols:
                    indicators_df = processed_df[['Close'] + indicator_cols].tail(30)
                    st.dataframe(indicators_df)
                
              
            # Tab 3: Predictions
            with tab3:
                st.subheader(f"Bitcoin Price Predictions (Next {prediction_days} Days)")
                
                # Generate predictions
                future_predictions = {}
                
                # Get dates for future prediction
                last_date = df.index[-1]
                future_dates = [last_date + timedelta(days=i+1) for i in range(prediction_days)]
                
                # Make predictions with selected models
                for model_name in selected_models:
                    if model_name == "LSTM Neural Network":
                        # Predict with LSTM
                        lstm_preds = make_lstm_predictions(
                            models["LSTM"], 
                            processed_df, 
                            lstm_scaler,
                            days_to_predict=prediction_days
                        )
                        future_predictions["LSTM Neural Network"] = lstm_preds
                    else:
                        # Predict with ML models
                        if model_name in models:
                            ml_preds = make_ml_predictions(
                                models[model_name], 
                                processed_df,
                                scaler,
                                feature_names,
                                days_to_predict=prediction_days
                            )
                            future_predictions[model_name] = ml_preds
                
                # Plot future predictions
                if future_predictions:
                    fig = plot_predictions(df.tail(30), future_dates, future_predictions)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Display prediction values in a table
                    st.subheader("Predicted Values")
                    
                    # Create a dataframe with predictions
                    pred_df = pd.DataFrame(index=future_dates)
                    for model_name, preds in future_predictions.items():
                        pred_df[model_name] = preds
                    
                    # Format the dataframe for display
                    formatted_df = pred_df.copy()
                    for col in formatted_df.columns:
                        formatted_df[col] = formatted_df[col].apply(lambda x: f"${x:,.2f}")
                    
                    st.dataframe(formatted_df)
                else:
                    st.warning("No models selected for prediction.")
                
                # Show prediction summary
                st.subheader("Prediction Summary")
                
                # Calculate average prediction for the first predicted day
                if future_predictions:
                    avg_first_day = np.mean([preds[0] for preds in future_predictions.values()])
                    price_diff = avg_first_day - latest_price
                    percent_change = (price_diff / latest_price) * 100
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        create_metric_card(
                            title="Current Price",
                            value=f"${latest_price:.2f}"
                        )
                    
                    with col2:
                        create_metric_card(
                            title="Next Day Prediction (Avg)",
                            value=f"${avg_first_day:.2f}",
                            delta=f"{percent_change:.2f}%"
                        )
                    
                    with col3:
                        # Find the model with best performance
                        best_model = min(performance_metrics.items(), key=lambda x: x[1]["mae"])[0]
                        best_model_readable = "LSTM Neural Network" if best_model == "LSTM" else best_model
                        create_metric_card(
                            title="Best Performing Model",
                            value=best_model_readable
                        )
                
               
            # Tab 4: Model Performance
            with tab4:
                st.subheader("Model Performance Metrics")
                
                if performance_metrics:
                    # Create a metrics comparison table
                    metrics_df = pd.DataFrame({
                        model_name: {
                            "MAE": metrics["mae"],
                            "MSE": metrics["mse"],
                            "RMSE": metrics["rmse"],
                            "R²": metrics["r2"]
                        }
                        for model_name, metrics in performance_metrics.items()
                    }).T  # Transpose to have models as rows
                    
                    st.dataframe(metrics_df.style.highlight_min(axis=0, subset=["MAE", "MSE", "RMSE"])
                                         .highlight_max(axis=0, subset=["R²"]))
                    
                    # Plot model performance comparison
                    fig = plot_model_performance(performance_metrics)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Plot actual vs predicted for test data
                    st.subheader("Model Predictions on Test Data")
                    
                    # Create test predictions for visualization
                    test_predictions = {}
                    for model_name in selected_models:
                        if model_name == "LSTM Neural Network" and "LSTM" in models:
                            # LSTM test predictions are already in the metrics
                            test_predictions["LSTM Neural Network"] = performance_metrics["LSTM"]["test_predictions"]
                        elif model_name in models:
                            # Make predictions on the test set
                            y_pred = models[model_name].predict(X_test)
                            
                            # Create a dummy array for inverse transform
                            dummy_pred = np.zeros((len(y_pred), len(feature_names) + 1))
                            dummy_pred[:, -1] = y_pred  # Place predictions in the last column
                            
                            # Inverse transform
                            y_pred_inv = scaler.inverse_transform(dummy_pred)[:, -1]
                            test_predictions[model_name] = y_pred_inv
                    
                    # Inverse transform the actual test values
                    dummy_test = np.zeros((len(y_test), len(feature_names) + 1))
                    dummy_test[:, -1] = y_test.flatten()  # Place actual values in the last column
                    y_test_inv = scaler.inverse_transform(dummy_test)[:, -1]
                    
                    # Create dataframe for plotting
                    test_dates = df.index[-len(y_test):]
                    test_df = pd.DataFrame({"Actual": y_test_inv}, index=test_dates)
                    
                    # Add model predictions
                    for model_name, preds in test_predictions.items():
                        if len(preds) == len(test_df):
                            test_df[model_name] = preds
                    
                    # Plot
                    fig = go.Figure()
                    
                    # Add actual values
                    fig.add_trace(go.Scatter(
                        x=test_df.index,
                        y=test_df["Actual"],
                        mode="lines",
                        name="Actual Price",
                        line=dict(color="black", width=2)
                    ))
                    
                    # Add predicted values
                    colors = ["blue", "green", "red", "purple"]
                    for i, (model_name, preds) in enumerate(test_predictions.items()):
                        if model_name in test_df.columns:
                            fig.add_trace(go.Scatter(
                                x=test_df.index,
                                y=test_df[model_name],
                                mode="lines",
                                name=f"{model_name} Predictions",
                                line=dict(color=colors[i % len(colors)])
                            ))
                    
                    # Update layout
                    fig.update_layout(
                        title="Model Predictions vs Actual Prices (Test Data)",
                        xaxis_title="Date",
                        yaxis_title="Price (USD)",
                        legend=dict(x=0, y=1),
                        hovermode="x unified"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.warning("No model performance metrics available. Please select and train models first.")
                
              
        else:
            st.error("Failed to retrieve Bitcoin data. Please try again later.")
    
except Exception as e:
    st.error(f"An error occurred: {str(e)}")
    st.code(traceback.format_exc())
    logger.error(f"Exception: {str(e)}")
    logger.error(traceback.format_exc())

# Add a refresh button
if st.button("Refresh Data"):
    st.rerun()

# Footer
st.markdown("---")
st.markdown("*Bitcoin price prediction app - for educational purposes only* By Group 7")
