import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
import logging
import time
import math
import requests
from pandas.tseries.offsets import BDay

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fetch_bitcoin_data(ticker="BTC-USD", days=365):
    """
    Fetch Bitcoin historical data using yfinance.
    
    Args:
        ticker (str): The ticker symbol for Bitcoin
        days (int): Number of days of historical data to fetch
    
    Returns:
        pd.DataFrame: DataFrame with Bitcoin price data
    """
    try:
        # Calculate start and end dates
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Fetch data with retry mechanism
        max_retries = 3
        for attempt in range(max_retries):
            try:
                logger.info(f"Fetching {ticker} data from {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
                data = yf.download(ticker, start=start_date, end=end_date, progress=False)
                
                if data.empty:
                    logger.warning(f"No data received for {ticker}. Attempt {attempt+1}/{max_retries}")
                    if attempt < max_retries - 1:
                        time.sleep(2)  # Wait before retrying
                        continue
                    else:
                        return None
                
                # Handle MultiIndex in columns if present
                if isinstance(data.columns, pd.MultiIndex):
                    # Flatten the MultiIndex by taking the first level
                    data.columns = data.columns.get_level_values(0)
                    logger.info(f"Flattened MultiIndex columns to: {data.columns.tolist()}")
                
                # Drop any missing values
                data = data.dropna()
                
                # Check if we have enough data
                if len(data) < days * 0.7:  # At least 70% of requested days
                    logger.warning(f"Insufficient data received for {ticker}. Got {len(data)} days, expected around {days} days.")
                
                logger.info(f"Successfully fetched {len(data)} days of {ticker} data")
                return data
            
            except Exception as e:
                logger.error(f"Error fetching data on attempt {attempt+1}/{max_retries}: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(2)  # Wait before retrying
                else:
                    return None
    
    except Exception as e:
        logger.error(f"Error in fetch_bitcoin_data: {str(e)}")
        return None

def calculate_technical_indicators(df):
    """
    Calculate technical indicators for the given dataframe.
    
    Args:
        df (pd.DataFrame): DataFrame with OHLCV data
    
    Returns:
        pd.DataFrame: DataFrame with added technical indicators
    """
    try:
        # Make a copy to avoid modifying the original
        df_indicators = df.copy()
        
        # Moving Averages
        df_indicators['MA7'] = df_indicators['Close'].rolling(window=7).mean()
        df_indicators['MA14'] = df_indicators['Close'].rolling(window=14).mean()
        df_indicators['MA30'] = df_indicators['Close'].rolling(window=30).mean()
        
        # MACD
        df_indicators['EMA12'] = df_indicators['Close'].ewm(span=12, adjust=False).mean()
        df_indicators['EMA26'] = df_indicators['Close'].ewm(span=26, adjust=False).mean()
        df_indicators['MACD'] = df_indicators['EMA12'] - df_indicators['EMA26']
        df_indicators['Signal_Line'] = df_indicators['MACD'].ewm(span=9, adjust=False).mean()
        
        # RSI
        delta = df_indicators['Close'].diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        
        # Calculate RS and RSI
        rs = avg_gain / avg_loss
        df_indicators['RSI'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        df_indicators['BB_middle'] = df_indicators['Close'].rolling(window=20).mean()
        df_indicators['BB_std'] = df_indicators['Close'].rolling(window=20).std()
        df_indicators['BB_upper'] = df_indicators['BB_middle'] + (df_indicators['BB_std'] * 2)
        df_indicators['BB_lower'] = df_indicators['BB_middle'] - (df_indicators['BB_std'] * 2)
        
        # Calculate Bollinger Band position - making sure it's scalar
        df_indicators['BB_position'] = ((df_indicators['Close'] - df_indicators['BB_lower']) / 
                                      (df_indicators['BB_upper'] - df_indicators['BB_lower'])).astype(float)
        
        # Add price change percentage
        df_indicators['Price_Change'] = df_indicators['Close'].pct_change() * 100
        
        # Add volatility (standard deviation of price changes)
        df_indicators['Volatility'] = df_indicators['Price_Change'].rolling(window=14).std()
        
        # Add volume change
        df_indicators['Volume_Change'] = df_indicators['Volume'].pct_change() * 100
        
        # Price Rate of Change (ROC)
        df_indicators['ROC'] = ((df_indicators['Close'] / df_indicators['Close'].shift(10)) - 1) * 100
        
        return df_indicators
        
    except Exception as e:
        logger.error(f"Error in calculate_technical_indicators: {str(e)}")
        # If there's an error, return the original dataframe
        return df

def process_data(df):
    """
    Process the raw data and prepare it for model training.
    
    Args:
        df (pd.DataFrame): Raw OHLCV data
    
    Returns:
        pd.DataFrame: Processed dataframe with technical indicators
    """
    try:
        # Calculate technical indicators
        processed_df = calculate_technical_indicators(df)
        
        # Fill NA values that might have been created by indicators
        processed_df = processed_df.bfill().ffill()
        
        # Drop rows that still have NaN values
        processed_df = processed_df.dropna()
        
        # Convert all values to float for consistency
        for col in processed_df.columns:
            processed_df[col] = processed_df[col].astype(float)
        
        logger.info(f"Processed data successfully. Shape: {processed_df.shape}")
        return processed_df
        
    except Exception as e:
        logger.error(f"Error processing data: {str(e)}")
        # If there's an error in processing, return the original dataframe
        return df
